# Weather-Forecast-Website
A complete weather forecast website with some features like hourly forecast, daily forecast of your geo-location and also for searched city.

Technologies used are HTML, CSS, javascript and openweathermap api.

**Demo of the website**
![weather-ss](https://user-images.githubusercontent.com/86728023/137619343-47622a40-3189-46d3-81e8-eda108df2050.png)

